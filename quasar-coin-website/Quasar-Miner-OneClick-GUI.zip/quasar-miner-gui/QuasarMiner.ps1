# ============================================================
#  QUASAR MINING - One-Click GUI Miner  (v1)
#  Double-click "Start-Quasar-Mining.vbs". No typing. No black window.
#  The big button does everything automatically:
#    Python check (auto-download+install if missing) ->
#    components -> wallet -> miner starts hidden -> live status.
# ============================================================

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

$script:PYEXE  = $null
$script:PYPRE  = @()
$script:DATADIR = $null
$script:MINING  = $false

# ---------------- helpers ----------------

function Log([string]$msg) {
    $logBox.AppendText(("[{0}] {1}`r`n" -f (Get-Date -Format "HH:mm:ss"), $msg))
    $logBox.SelectionStart = $logBox.Text.Length
    $logBox.ScrollToCaret()
}

function Find-DataDir {
    $cands = @(
        (Join-Path $scriptDir "quasar-seed"),
        (Join-Path ([Environment]::GetFolderPath("UserProfile")) "Downloads\Quasar-Core-Stage2-FINAL-v3-30s-3PHASE\quasar-seed")
    )
    foreach ($c in $cands) { if (Test-Path $c) { return $c } }
    $new = $cands[0]
    New-Item -ItemType Directory -Force -Path $new | Out-Null
    return $new
}

function Find-Python {
    try { & py -3 --version 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { $script:PYEXE="py"; $script:PYPRE=@("-3"); return $true } } catch {}
    try { & python --version 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { $script:PYEXE="python"; $script:PYPRE=@(); return $true } } catch {}
    $probes = @(
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe",
        "C:\Program Files\Python312\python.exe",
        "C:\Python312\python.exe"
    )
    foreach ($p in $probes) {
        if (Test-Path $p) { $script:PYEXE=$p; $script:PYPRE=@(); return $true }
    }
    return $false
}

function Invoke-Py {
    param([string[]]$PyArgs)
    & $script:PYEXE @script:PYPRE @PyArgs 2>&1
}

function Install-Python {
    Log "Python not found - downloading automatically (one time only)..."
    [System.Windows.Forms.Application]::DoEvents()
    $url = "https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe"
    $dst = Join-Path $env:TEMP "quasar-python-setup.exe"
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        (New-Object Net.WebClient).DownloadFile($url, $dst)
    } catch {
        Log "Auto-download failed. Opening python.org for you..."
        Start-Process "https://www.python.org/downloads/"
        Log "Install Python (tick 'Add python.exe to PATH'), then press START MINING again."
        return $false
    }
    Log "Installing Python silently (no admin needed)..."
    [System.Windows.Forms.Application]::DoEvents()
    try { Start-Process $dst -ArgumentList "/quiet InstallAllUsers=0 PrependPath=1 Include_test=0" -Wait } catch {}
    $exe = "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe"
    if (Test-Path $exe) {
        $script:PYEXE = $exe; $script:PYPRE = @()
        Log "Python installed - OK."
        return $true
    }
    Log "Install finished but python.exe not found. Install manually, then press START again."
    return $false
}

function Get-SeedArg {
    $sf = Join-Path $scriptDir "seed.txt"
    if (-not (Test-Path $sf)) { return "" }
    $line = (Get-Content $sf -TotalCount 1).Trim()
    if ([string]::IsNullOrWhiteSpace($line)) { return "" }
    if ($line.StartsWith("#")) { return "" }
    if ($line -like "*REPLACE_THIS*") { return "" }
    return "--seed " + $line
}

function Node-Running {
    $procs = Get-CimInstance Win32_Process -Filter "Name='python.exe' OR Name='pythonw.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like "*quasar_cli.py*start-node*" }
    return ($null -ne $procs)
}

function Poll-Status {
    if (-not $script:MINING) { return }
    if (-not (Node-Running)) {
        $statusLabel.Text = "Miner stopped."
        $statusLabel.ForeColor = [System.Drawing.Color]::DarkRed
        $script:MINING = $false
        $pollTimer.Stop()
        $stopBtn.Enabled = $false
        $startBtn.Enabled = $true
        Log "Miner process ended."
        return
    }
    try {
        $info = (Invoke-Py @("quasar_cli.py","info") | Out-String)
        $h = "?"; $b = "?"
        if ($info -match "Chain height:\s+(\d+)") { $h = $matches[1] }
        $bal = (Invoke-Py @("quasar_cli.py","balance","miner") | Out-String)
        if ($bal -match ":\s*([0-9,\.]+)\s*QSR") { $b = $matches[1] }
        $statusLabel.Text = ("Mining...   Block " + $h + "    |    Balance " + $b + " QSR")
        $statusLabel.ForeColor = [System.Drawing.Color]::DarkGreen
    } catch {}
}

# ---------------- GUI ----------------

$form = New-Object System.Windows.Forms.Form
$form.Text = "Quasar Mining"
$form.Size = New-Object System.Drawing.Size(520, 470)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.BackColor = [System.Drawing.Color]::FromArgb(255, 248, 240)

$title = New-Object System.Windows.Forms.Label
$title.Text = "QUASAR MINING"
$title.Font = New-Object System.Drawing.Font("Segoe UI", 20, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::FromArgb(200, 90, 10)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(20, 15)
$form.Controls.Add($title)

$sub = New-Object System.Windows.Forms.Label
$sub.Text = "One click. No typing. No black window."
$sub.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$sub.ForeColor = [System.Drawing.Color]::FromArgb(90, 70, 60)
$sub.AutoSize = $true
$sub.Location = New-Object System.Drawing.Point(22, 52)
$form.Controls.Add($sub)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = "Ready. Press START MINING."
$statusLabel.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
$statusLabel.AutoSize = $false
$statusLabel.Size = New-Object System.Drawing.Size(460, 30)
$statusLabel.Location = New-Object System.Drawing.Point(20, 82)
$form.Controls.Add($statusLabel)

$startBtn = New-Object System.Windows.Forms.Button
$startBtn.Text = "START MINING"
$startBtn.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$startBtn.Size = New-Object System.Drawing.Size(220, 60)
$startBtn.Location = New-Object System.Drawing.Point(20, 120)
$startBtn.BackColor = [System.Drawing.Color]::Gold
$startBtn.FlatStyle = "Flat"
$form.Controls.Add($startBtn)

$stopBtn = New-Object System.Windows.Forms.Button
$stopBtn.Text = "STOP"
$stopBtn.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$stopBtn.Size = New-Object System.Drawing.Size(220, 60)
$stopBtn.Location = New-Object System.Drawing.Point(260, 120)
$stopBtn.Enabled = $false
$form.Controls.Add($stopBtn)

$logBox = New-Object System.Windows.Forms.TextBox
$logBox.Multiline = $true
$logBox.ReadOnly = $true
$logBox.ScrollBars = "Vertical"
$logBox.Font = New-Object System.Drawing.Font("Consolas", 9)
$logBox.Size = New-Object System.Drawing.Size(460, 185)
$logBox.Location = New-Object System.Drawing.Point(20, 195)
$form.Controls.Add($logBox)

$pollTimer = New-Object System.Windows.Forms.Timer
$pollTimer.Interval = 10000
$pollTimer.Add_Tick({ Poll-Status })

# ---------------- button actions ----------------

$startBtn.Add_Click({
    $startBtn.Enabled = $false
    try {
        if (-not (Find-Python)) {
            if (-not (Install-Python)) { $startBtn.Enabled = $true; return }
        }
        Log "Python found - OK."
        [System.Windows.Forms.Application]::DoEvents()

        $script:DATADIR = Find-DataDir
        $env:QUASAR_DATA_DIR = $script:DATADIR
        Log ("Data folder: " + $script:DATADIR)
        [System.Windows.Forms.Application]::DoEvents()

        Log "Preparing components..."
        [System.Windows.Forms.Application]::DoEvents()
        Invoke-Py @("-m","pip","install","--quiet","--disable-pip-version-check","ecdsa") | Out-Null
        Log "Components ready - OK."

        if (-not (Test-Path (Join-Path $script:DATADIR "wallets\miner.json"))) {
            Log "Creating your wallet (one time only)..."
            Invoke-Py @("quasar_cli.py","new-address","miner") | Out-Null
            Log "Wallet created - OK."
        } else {
            Log "Wallet found - OK."
        }
        [System.Windows.Forms.Application]::DoEvents()

        if (Node-Running) {
            Log "Miner already running - attaching."
        } else {
            $seedArg = Get-SeedArg
            if ($seedArg -ne "") { Log "Joining network seed..." }
            Log "Starting miner in background (no window)..."
            [System.Windows.Forms.Application]::DoEvents()
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = $script:PYEXE
            $psi.Arguments = 'quasar_cli.py start-node --datadir "' + $script:DATADIR + '" --mine-auto miner ' + $seedArg
            $psi.WorkingDirectory = $scriptDir
            $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
            $psi.CreateNoWindow = $true
            $psi.UseShellExecute = $false
            [System.Diagnostics.Process]::Start($psi) | Out-Null
            Start-Sleep -Seconds 4
        }

        $script:MINING = $true
        $stopBtn.Enabled = $true
        $pollTimer.Start()
        Poll-Status
        Log "MINING STARTED - new coins every ~30 sec go to your wallet."
    } catch {
        Log ("ERROR: " + $_.Exception.Message)
        $startBtn.Enabled = $true
    }
})

$stopBtn.Add_Click({
    Log "Stopping miner..."
    Get-CimInstance Win32_Process -Filter "Name='python.exe' OR Name='pythonw.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like "*quasar_cli.py*start-node*" } |
        ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force } catch {} }
    $script:MINING = $false
    $pollTimer.Stop()
    $statusLabel.Text = "Miner stopped. Coins are saved - nothing is lost."
    $statusLabel.ForeColor = [System.Drawing.Color]::DarkRed
    $stopBtn.Enabled = $false
    $startBtn.Enabled = $true
    Log "Stopped. Press START MINING anytime to resume."
})

$form.Add_Shown({ Log "Welcome to Quasar Mining. Press START MINING." })
[void]$form.ShowDialog()
